module.exports = {
    mapKey: '035bb2902d763bd38ade9c529c49f1f8' // 高德地图 key
}