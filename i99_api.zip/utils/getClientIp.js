module.exports = function getClientIp (req) {
    return req.headers['x-forwarded-for'] ||
        req.headers['x-real-ip'] || null
}